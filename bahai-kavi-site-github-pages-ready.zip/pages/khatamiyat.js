/**
 * Khatamiyat page explores the doctrine of finality of prophecy and offers critical analysis.
 */
export default function Khatamiyat() {
  return (
    <main style={{ padding: '20px' }}>
      <h1>Khatamiyat</h1>
      <p>Linguistic and technical definition of Khatamiyat.</p>
      <p>Khatamiyat in the Qur&#39;an.</p>
      <p>Khatamiyat in Islamic theology.</p>
      <p>Historical consensus of Muslims.</p>
      <p>Relationship between Khatamiyat and Mahdism.</p>
      <p>Claims of continued revelation by the Baha'i movement.</p>
      <p>Theological critiques of such claims.</p>
      <p>Religious and intellectual consequences of denying Khatamiyat.</p>
      <p>Social and identity impacts of these beliefs.</p>
      <p>Analytical questions for further research.</p>
    </main>
  );
}
