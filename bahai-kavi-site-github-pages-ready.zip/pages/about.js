/**
 * About page introduces the Bahai Kavi initiative, its mission and methodology.
 */
export default function About() {
  return (
    <main style={{ padding: '20px' }}>
      <h1>About Bahai Kavi</h1>
      <h2>Mission and Purpose</h2>
      <p>
        Bahai Kavi is an independent research initiative that critically analyzes
        the doctrinal, historical and social aspects of the Baha'i movement with an academic
        and non-proselytizing approach.
      </p>
      <h2>Definition of Bahai Kavi</h2>
      <p>
        We seek to shed light on inconsistencies, claims and impacts of the Baha'i faith while
        guiding seekers towards authentic teachings.
      </p>
      <h2>Research Approach and Methodology</h2>
      <p>
        Our work relies on primary sources, scholarly analysis and respect for academic rigor
        and ethical standards.
      </p>
      <h2>Content Policy</h2>
      <p>
        We avoid direct attacks or inflammatory language; our content aims to inform and provide
        critical insight.
      </p>
      <h2>Non-proselytizing Stance</h2>
      <p>
        We provide research and guidance without coercion or propaganda.
      </p>
      <h2>Security Considerations</h2>
      <p>
        We protect our researchers and contributors; sensitive details are handled discreetly.
      </p>
      <p>
        Contact methods are listed on our contact page.
      </p>
    </main>
  );
}
