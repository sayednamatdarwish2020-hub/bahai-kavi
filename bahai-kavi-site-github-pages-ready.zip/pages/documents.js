/**
 * Documents page provides categories of source materials for research.
 */
export default function Documents() {
  return (
    <main style={{ padding: '20px' }}>
      <h1>Documents and Resources</h1>
      <p>Access our research sources:</p>
      <ul>
        <li>Islamic sources</li>
        <li>Academic sources</li>
        <li>Baha'i texts (for critique)</li>
        <li>Historical documents</li>
        <li>Translations</li>
        <li>PDF Archive</li>
      </ul>
    </main>
  );
}
