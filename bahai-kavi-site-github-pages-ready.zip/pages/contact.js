/**
 * Contact page provides a simple contact form and alternative contact method.
 */
export default function Contact() {
  return (
    <main style={{ padding: '20px' }}>
      <h1>Contact Us</h1>
      <p>
        If you have questions, feedback or would like to collaborate, please reach out via the
        following form:
      </p>
      <form style={{ maxWidth: '500px' }}>
        <div style={{ marginBottom: '10px' }}>
          <label htmlFor="name">Name</label>
          <br />
          <input
            type="text"
            id="name"
            name="name"
            style={{ width: '100%', padding: '8px' }}
          />
        </div>
        <div style={{ marginBottom: '10px' }}>
          <label htmlFor="email">Email</label>
          <br />
          <input
            type="email"
            id="email"
            name="email"
            style={{ width: '100%', padding: '8px' }}
          />
        </div>
        <div style={{ marginBottom: '10px' }}>
          <label htmlFor="message">Message</label>
          <br />
          <textarea
            id="message"
            name="message"
            rows="4"
            style={{ width: '100%', padding: '8px' }}
          ></textarea>
        </div>
        <button
          type="submit"
          style={{
            background: 'var(--accent-color)',
            border: 'none',
            color: '#fff',
            padding: '10px 20px',
            borderRadius: '4px',
            cursor: 'pointer',
          }}
        >
          Send
        </button>
      </form>
      <p style={{ marginTop: '20px' }}>
        Alternatively, you can email us at{' '}
        <a href="mailto:info@bahai-kavi-site.org">info@bahai-kavi-site.org</a>.
      </p>
    </main>
  );
}
