import HeroSlider from '../components/HeroSlider';
import ContentMap from '../components/ContentMap';

/**
 * Home page composes the hero slider and the content map.
 * It provides a clear overview of the site's purpose and main sections.
 */
export default function Home() {
  return (
    <main>
      <HeroSlider />
      <ContentMap />
    </main>
  );
}
