/**
 * Articles page summarises categories of research articles available on the site.
 */
export default function Articles() {
  return (
    <main style={{ padding: '20px' }}>
      <h1>Research Articles</h1>
      <p>Select a category to explore our research articles:</p>
      <ul>
        <li>Theology and Islamic studies</li>
        <li>Conceptual and doctrinal critiques</li>
        <li>Qaemiyat and Mahdism</li>
        <li>Khatamiyat and Revelation</li>
        <li>Local context and societal impact</li>
        <li>Comparative religious studies</li>
      </ul>
    </main>
  );
}
