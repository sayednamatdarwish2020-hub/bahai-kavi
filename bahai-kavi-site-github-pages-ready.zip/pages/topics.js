/**
 * Topics page lists various subject-specific critiques that the site covers.
 */
export default function Topics() {
  return (
    <main style={{ padding: '20px' }}>
      <h1>Topical Critiques</h1>
      <p>Explore subject-specific critiques:</p>
      <ul>
        <li>Religion and freedom</li>
        <li>Baha'i and human rights</li>
        <li>Religious propagation and social ethics</li>
        <li>Religion and identity in traditional society</li>
        <li>Media narratives and their influence</li>
        <li>Role of international institutions</li>
        <li>Critique of peace-centric discourse</li>
      </ul>
    </main>
  );
}
