import Link from 'next/link';

// Definitions of the main sections with brief subitems.
const sections = [
  {
    title: 'Local Insight',
    link: '/local-insight',
    items: [
      'Analytical introduction',
      'Historical presence',
      'Social distribution',
    ],
  },
  {
    title: 'Qaemiyat',
    link: '/qaemiyat',
    items: [
      'Concept in Islamic thought',
      'Criteria for the Qaem',
      'Comparative critiques',
    ],
  },
  {
    title: 'Khatamiyat',
    link: '/khatamiyat',
    items: [
      'Definition & terminology',
      'In the Qur’​n',
      'Doctrinal implications',
    ],
  },
  {
    title: 'Articles',
    link: '/articles',
    items: [
      'Theology & Islamic studies',
      'Conceptual critiques',
      'Comparative research',
    ],
  },
  {
    title: 'Topics',
    link: '/topics',
    items: [
      'Religion & freedom',
      'Human rights',
      'Social ethics',
    ],
  },
  {
    title: 'Documents',
    link: '/documents',
    items: [
      'Islamic sources',
      'Academic sources',
      'Historical documents',
    ],
  },
  {
    title: 'About Us',
    link: '/about',
    items: [
      'Mission & purpose',
      'Research methodology',
      'Content policy',
    ],
  },
  {
    title: 'Contact',
    link: '/contact',
    items: [
      'Get in touch',
      'Collaborations',
      'Feedback',
    ],
  },
];

/**
 * ContentMap displays a grid of cards summarizing the site's main sections
 * with three example subitems each. Cards provide quick navigation to
 * deeper content pages.
 */
export default function ContentMap() {
  return (
    <div
      className="content-map"
      style={{
        display: 'flex',
        flexWrap: 'wrap',
        gap: '20px',
        justifyContent: 'center',
        margin: '40px 0',
      }}
    >
      {sections.map((section) => (
        <div
          key={section.title}
          style={{
            flex: '1 1 300px',
            background: 'var(--secondary-color)',
            color: '#fff',
            padding: '20px',
            borderRadius: '8px',
            minWidth: '250px',
            maxWidth: '300px',
          }}
        >
          <h3 style={{ marginTop: 0 }}>{section.title}</h3>
          <ul style={{ paddingLeft: '20px', margin: '10px 0' }}>
            {section.items.map((item, idx) => (
              <li key={idx} style={{ marginBottom: '6px' }}>
                {item}
              </li>
            ))}
          </ul>
          <Link href={section.link}>
            <button
              style={{
                background: 'var(--accent-color)',
                border: 'none',
                color: '#fff',
                padding: '8px 12px',
                borderRadius: '4px',
                cursor: 'pointer',
              }}
            >
              Explore
            </button>
          </Link>
        </div>
      ))}
    </div>
  );
}
