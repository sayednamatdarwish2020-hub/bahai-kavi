import Link from 'next/link';
import { useTheme } from './ThemeContext';
import { useState } from 'react';

/**
 * Header component renders the top navigation bar, including
 * navigation links, theme toggle button and language selection.
 * It adapts between desktop and mobile viewports using media queries.
 */
export default function Header() {
  const { theme, toggleTheme } = useTheme();
  const [menuOpen, setMenuOpen] = useState(false);

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  return (
    <header
      style={{
        backgroundColor: 'var(--primary-color)',
        color: '#fff',
        padding: '10px 20px',
        position: 'sticky',
        top: 0,
        zIndex: 1000,
      }}
    >
      <div
        className="header-inner"
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}
      >
        <div className="logo">
          <Link href="/">
            <span style={{ fontWeight: 'bold', fontSize: '1.2rem', color: '#fff' }}>
              Bahai Kavi
            </span>
          </Link>
        </div>
        {/* Desktop navigation */}
        <nav className="nav-desktop" style={{ display: 'none' }}>
          <Link href="/">Home</Link>
          <Link href="/local-insight" style={{ marginLeft: '15px' }}>
            Local Insight
          </Link>
          <Link href="/qaemiyat" style={{ marginLeft: '15px' }}>
            Qaemiyat
          </Link>
          <Link href="/khatamiyat" style={{ marginLeft: '15px' }}>
            Khatamiyat
          </Link>
          <Link href="/articles" style={{ marginLeft: '15px' }}>
            Articles
          </Link>
          <Link href="/topics" style={{ marginLeft: '15px' }}>
            Topics
          </Link>
          <Link href="/documents" style={{ marginLeft: '15px' }}>
            Documents
          </Link>
          <Link href="/about" style={{ marginLeft: '15px' }}>
            About
          </Link>
          <Link href="/contact" style={{ marginLeft: '15px' }}>
            Contact
          </Link>
        </nav>
        <div
          className="controls"
          style={{ display: 'flex', alignItems: 'center' }}
        >
          {/* Theme toggle button with sun/moon icons */}
          <button
            onClick={toggleTheme}
            aria-label="Toggle theme"
            style={{
              marginRight: '10px',
              background: 'none',
              border: 'none',
              color: '#fff',
              cursor: 'pointer',
              fontSize: '1.2rem',
            }}
          >
            {theme === 'light' ? '🌙' : '☀️'}
          </button>
          {/* Language selector placeholder */}
          <select
            style={{
              background: 'none',
              border: '1px solid #fff',
              color: '#fff',
              padding: '4px 6px',
            }}
            aria-label="Select language"
          >
            <option value="en">EN</option>
            <option value="fa">FA</option>
            <option value="ps">PS</option>
          </select>
          {/* Hamburger menu for mobile */}
          <button
            onClick={toggleMenu}
            aria-label="Toggle navigation"
            style={{
              marginLeft: '10px',
              background: 'none',
              border: 'none',
              color: '#fff',
              fontSize: '1.5rem',
              display: 'none',
            }}
          >
            ☰
          </button>
        </div>
      </div>
      {/* Mobile navigation */}
      <div className="nav-mobile" style={{ display: 'none' }}>
        <nav
          style={{
            display: menuOpen ? 'block' : 'none',
            backgroundColor: 'var(--primary-color)',
            padding: '10px 0',
          }}
        >
          <Link href="/" onClick={() => setMenuOpen(false)}>
            <span style={{ display: 'block', padding: '8px 20px' }}>Home</span>
          </Link>
          <Link href="/local-insight" onClick={() => setMenuOpen(false)}>
            <span style={{ display: 'block', padding: '8px 20px' }}>Local Insight</span>
          </Link>
          <Link href="/qaemiyat" onClick={() => setMenuOpen(false)}>
            <span style={{ display: 'block', padding: '8px 20px' }}>Qaemiyat</span>
          </Link>
          <Link href="/khatamiyat" onClick={() => setMenuOpen(false)}>
            <span style={{ display: 'block', padding: '8px 20px' }}>Khatamiyat</span>
          </Link>
          <Link href="/articles" onClick={() => setMenuOpen(false)}>
            <span style={{ display: 'block', padding: '8px 20px' }}>Articles</span>
          </Link>
          <Link href="/topics" onClick={() => setMenuOpen(false)}>
            <span style={{ display: 'block', padding: '8px 20px' }}>Topics</span>
          </Link>
          <Link href="/documents" onClick={() => setMenuOpen(false)}>
            <span style={{ display: 'block', padding: '8px 20px' }}>Documents</span>
          </Link>
          <Link href="/about" onClick={() => setMenuOpen(false)}>
            <span style={{ display: 'block', padding: '8px 20px' }}>About</span>
          </Link>
          <Link href="/contact" onClick={() => setMenuOpen(false)}>
            <span style={{ display: 'block', padding: '8px 20px' }}>Contact</span>
          </Link>
        </nav>
      </div>
      <style jsx>{`
        @media (min-width: 768px) {
          .nav-desktop {
            display: flex;
          }
          .nav-desktop a {
            color: #fff;
            margin-left: 15px;
          }
          .nav-mobile {
            display: none;
          }
          .header-inner button:nth-of-type(3) {
            /* hide hamburger button on desktop */
            display: none;
          }
        }
        @media (max-width: 767px) {
          .nav-desktop {
            display: none;
          }
          .header-inner button:nth-of-type(3) {
            display: block;
          }
          .nav-mobile {
            display: block;
          }
        }
      `}</style>
    </header>
  );
}
