/**
 * Footer component provides a simple footer that appears on every page.
 * It adapts colors based on the active theme via CSS variables.
 */
export default function Footer() {
  return (
    <footer
      style={{
        backgroundColor: 'var(--secondary-color)',
        color: '#fff',
        padding: '20px',
        textAlign: 'center',
        marginTop: 'auto',
      }}
    >
      <p>© {new Date().getFullYear()} Bahai Kavi. All rights reserved.</p>
    </footer>
  );
}
