import { createContext, useState, useContext, useEffect } from 'react';

const ThemeContext = createContext();

/**
 * ThemeProvider manages a light/dark mode for the site.
 * It reads a saved preference from localStorage if available and
 * falls back to the user's system preference on first load.
 */
export function ThemeProvider({ children }) {
  const [theme, setTheme] = useState('light');

  // On mount, determine initial theme from localStorage or system preference.
  useEffect(() => {
    const saved = typeof window !== 'undefined' && localStorage.getItem('theme');
    if (saved) {
      setTheme(saved);
    } else {
      const prefersDark =
        typeof window !== 'undefined' &&
        window.matchMedia &&
        window.matchMedia('(prefers-color-scheme: dark)').matches;
      setTheme(prefersDark ? 'dark' : 'light');
    }
  }, []);

  // Toggle between light and dark theme.
  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    if (typeof window !== 'undefined') {
      localStorage.setItem('theme', newTheme);
    }
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {/* Apply a class at the top-level to allow CSS variable switching */}
      <div className={theme}>{children}</div>
    </ThemeContext.Provider>
  );
}

export const useTheme = () => useContext(ThemeContext);
