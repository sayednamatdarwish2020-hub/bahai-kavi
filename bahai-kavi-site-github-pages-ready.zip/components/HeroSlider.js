import { useState, useEffect } from 'react';
import Link from 'next/link';

// Define slides for the home page carousel.
const slides = [
  {
    title: 'Bahai Kavi',
    subtitle: 'Analysis of claims and impacts',
    description: 'Research-based critique of Bahaism',
    buttonText: 'Learn More',
    buttonLink: '/local-insight',
  },
  {
    title: 'Research Statement',
    subtitle: 'Neutral and academic approach',
    description: 'Discover our research methodology',
    buttonText: 'Our Approach',
    buttonLink: '/about',
  },
  {
    title: 'Main Themes',
    subtitle: 'Explore major research themes',
    description: 'Qaemiyat, Khatamiyat, Theological Studies',
    buttonText: 'Themes',
    buttonLink: '/topics',
  },
  {
    title: 'Latest Articles',
    subtitle: 'Stay informed',
    description: 'Read the latest research articles',
    buttonText: 'Articles',
    buttonLink: '/articles',
  },
  {
    title: 'Latest Critiques',
    subtitle: 'Subject-specific critiques',
    description: 'Browse our topical critiques',
    buttonText: 'Critiques',
    buttonLink: '/topics',
  },
];

/**
 * HeroSlider displays a full-width slider at the top of the home page.
 * It automatically cycles through slides every 6 seconds but allows
 * manual selection via indicator dots.
 */
export default function HeroSlider() {
  const [index, setIndex] = useState(0);

  // Cycle through slides automatically on a timer.
  useEffect(() => {
    const timer = setInterval(() => {
      setIndex((prev) => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const slide = slides[index];

  return (
    <div className="hero-slider">
      <div className="slide" style={{ padding: '60px 20px', textAlign: 'center' }}>
        <h1 style={{ fontSize: '2rem', marginBottom: '0.5rem' }}>{slide.title}</h1>
        <h2 style={{ fontSize: '1.2rem', marginBottom: '1rem' }}>{slide.subtitle}</h2>
        <p style={{ marginBottom: '1.5rem' }}>{slide.description}</p>
        <Link href={slide.buttonLink}>
          <button
            style={{
              background: 'var(--accent-color)',
              border: 'none',
              color: '#fff',
              padding: '10px 20px',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '1rem',
            }}
          >
            {slide.buttonText}
          </button>
        </Link>
      </div>
      <div className="indicators" style={{ textAlign: 'center', marginBottom: '10px' }}>
        {slides.map((_, i) => (
          <span
            key={i}
            onClick={() => setIndex(i)}
            style={{
              display: 'inline-block',
              width: '12px',
              height: '12px',
              borderRadius: '50%',
              margin: '0 4px',
              background: i === index ? 'var(--accent-color)' : 'rgba(255, 255, 255, 0.5)',
              cursor: 'pointer',
            }}
          ></span>
        ))}
      </div>
      <style jsx>{`
        .hero-slider {
          background-image: linear-gradient(120deg, var(--primary-color), var(--secondary-color));
          color: #fff;
        }
      `}</style>
    </div>
  );
}
