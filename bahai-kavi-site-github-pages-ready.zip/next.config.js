/** @type {import('next').NextConfig} */
const isGithubPages = process.env.GITHUB_PAGES === "true";
const repo =
  process.env.GITHUB_REPOSITORY && process.env.GITHUB_REPOSITORY.includes("/")
    ? process.env.GITHUB_REPOSITORY.split("/")[1]
    : "";

const nextConfig = {
  // Static export so it can run on GitHub Pages
  output: "export",
  trailingSlash: true,

  // Required for static export if you ever use next/image
  images: { unoptimized: true },

  // If deploying to GitHub Pages as a project site (USERNAME.github.io/REPO),
  // GitHub sets GITHUB_REPOSITORY so we can auto-detect the repo name.
  basePath: isGithubPages && repo ? `/${repo}` : "",
  assetPrefix: isGithubPages && repo ? `/${repo}/` : "",
};

module.exports = nextConfig;
